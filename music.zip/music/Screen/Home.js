import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { Dimensions } from 'react-native'
import {songs} from './Song';
import MusicItem from './MusicItem';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;



const Home = () => {
  return (
    <View style={styles.maincontainer}>
      <View style={styles.header}>
        <Text style={styles.logo}>YuViMusic</Text>
      </View>

      
        <FlatList
          data={songs}
          renderItem={({item,index,songs})=>{
             return <MusicItem item={item} index={index} />
          }}
        />
     
    </View>

  )
}

export default Home

const styles = StyleSheet.create({
  maincontainer: {
    flex: 1,

  },
  
  logo: {
    fontWeight: '600',
    color: 'red',
    fontSize: 25,

    padding: 10


  },
  header: {
    elevation: 5,
    height: 60,
    width: '100%',
    backgroundColor: 'white',
    textAlign: 'center',
    justifyContent: 'center'
  }
})