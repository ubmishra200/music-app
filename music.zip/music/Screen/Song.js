export const songs = [
    {
      id: 1,
  
      title: 'death bed',
      artist: 'Powfu',
      artwork: require('../assets/img/1.jpg'),
      url: 'https://sample-music.netlify.app/death%20bed.mp3',
      duration: 2 * 60 + 53,
    },
    {
      id: 2,
  
      title: 'bad liar',
      artist: 'Imagine Dragons',
      artwork: require('../assets/img/2.jpg'),
      url: 'https://sample-music.netlify.app/Bad%20Liar.mp3',
      duration: 2 * 60,
    },
    {
      id: 3,
  
      title: 'faded',
      artist: 'Alan Walker',
      artwork: require('../assets/img/3.jpg'),
      url: 'https://sample-music.netlify.app/Faded.mp3',
      duration: 2 * 60,
    },
    {
      id: 4,
  
      title: 'hate me',
      artist: 'Ellie Goulding',
      artwork: require('../assets/img/4.jpg'),
      url: 'https://sample-music.netlify.app/Hate%20Me.mp3',
      duration: 2 * 60,
    },
    {
      id: 5,
  
      title: 'Solo',
      artist: 'Clean Bandit',
      artwork: require('../assets/img/5.jpg'),
      url: 'https://sample-music.netlify.app/Solo.mp3',
      duration: 2 * 60,
    },
    {
      id: 6,
  
      title: 'without me',
      artist: 'Halsey',
      artwork: require('../assets/img/1.jpg'),
      url: 'https://sample-music.netlify.app/Without%20Me.mp3',
      duration: 2 * 60,
    },
  ];
  
