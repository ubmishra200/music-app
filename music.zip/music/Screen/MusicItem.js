import { Dimensions, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import Ionicon from 'react-native-vector-icons/Ionicons'
import { useNavigation } from '@react-navigation/native'
//import Name from './Name';
const { height, width } = Dimensions.get('window');

const MusicItem = ({ item, index }) => {
  const navigation=useNavigation();

  return (
    <TouchableOpacity style={[styles.mainlistsong, { marginBottom: index == 5? 30 : 0 },]}
     onPress={()=>{navigation.navigate('Music',{name:item,id:index})}}
    >
    
      <Image source={item.artwork} style={styles.songImage} />
      <View style={styles.viewname}>
        <Text style={styles.name}>{item.title}</Text>
        <Text style={styles.name}>{item.artist}</Text>
      </View>
      <TouchableOpacity >
        <Text style={{marginTop:25}}><Ionicon style={styles.playicon} name="play-circle-outline" size={45} color="black" /></Text>
      </TouchableOpacity>
    </TouchableOpacity>
  )
}

export default MusicItem

const styles = StyleSheet.create({
  mainlistsong: {
    width: '100%',
    height: 100,
    elevation: 1,
    backgroundColor: '#fff',
    marginTop: 25,
    alignSelf: 'center',
    borderRadius: 10,
    flexDirection: 'row'

  },
  songImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
    marginLeft: 10,

  },
  viewname: {
    paddingLeft: 15,
    width: '50%',
    alingItem: 'center',
    justifyContent: 'center'
  },
  name: {
    color: 'black',
    fontSize: 18,
    fontWeight: '600'
  },
  playicon: {
    justifyContent: 'center',
    paddingTop: 25
  }
})