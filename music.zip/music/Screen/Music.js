import { Dimensions, FlatList, Image, StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useRef, useState } from 'react'
import { useRoute } from '@react-navigation/native'
import Slider from '@react-native-community/slider'
import Icon from 'react-native-vector-icons/Ionicons'
import { TouchableOpacity } from 'react-native'
import TrackPlayer,{Capability,usePlaybackState,useProgress,State} from 'react-native-track-player'
import { songs } from './Song'
import { pause } from 'react-native-track-player/lib/trackPlayer'
const { width, height } = Dimensions.get('window')
const Music = () => {

  const route = useRoute()
  const progress=useProgress()
  const playbackstate=usePlaybackState()
  const [currentsong, setcurrentsong] = useState(route.params.id);
  const [btn,setbtn]=useState(false)
  const ref = useRef()
  useEffect(() => {
    setTimeout(() => {

      ref.current.scrollToIndex({ animated: true, index: currentsong })
    }, 100)

  }, [])
  useEffect(()=>{
    setup()
  })
   const setup=async()=>{
    try{
      await TrackPlayer.setupPlayer()
      TrackPlayer.updateOptions({
        // Media controls capabilities
        capabilities: [
            Capability.Play,
            Capability.Pause,
            Capability.SkipToNext,
            Capability.SkipToPrevious,
            Capability.Stop,
        ],
    
        // Capabilities that will show up when the notification is in the compact form on Android
        compactCapabilities: [Capability.Play, Capability.Pause],
    
        // Icons for the notification on Android (if you don't like the default ones)
        
    });
    await TrackPlayer.add(songs)
    } catch(e){}
   }
   const toggleplayback=async( playbackstate)=>{
    console.log(playbackstate)
    if(playbackstate.state===State.Ready||playbackstate.state===State.None||playbackstate.state===State.Buffering||playbackstate.state===State.Paused){
     await TrackPlayer.play()
     setbtn(true)
    }else{
      await TrackPlayer.pause()
      setbtn(false)
    }
   
   }
  return (
    <View style={{ flex: 1 }}>
      <View>
        <FlatList data={songs}
          ref={ref}
          horizontal
          showsHorizontalScrollIndicator={false}
          pagingEnabled
          renderItem={({ item, index }) => {

            return <View style={{ width: width, height: height / 2 }}>
              <Image source={item.artwork} style={{ width: '90%', height: '100%', alignSelf: 'center', marginTop: 50, borderRadius: 10 }} />
                
            </View>

          }} />
      </View>

      <Text style={{ fontSize: 25, fontWeight: '600', textAlign: 'center', justifyContent: 'center', marginTop: 20 }}>
       {route.params.name.title}
      </Text>
      <Text style={{ fontSize: 25, fontWeight: '300', textAlign: 'center', justifyContent: 'center', marginTop: 5 }}>{route.params.name.artist}</Text>
      <View>

        <Slider
          style={{ width: '90%', height: 40, alignSelf: 'center' }}
          minimumValue={0}
          value={progress.position}
          maximumValue={progress.duration}
          minimumTrackTintColor="red"
          maximumTrackTintColor="#000000"
          onValueChange={async(value)=>{
            await TrackPlayer.seekTo(value)
          }}
        />
      </View>
      <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-evenly', alignItems: 'center' }}>
        <TouchableOpacity onPress={async () => {
          if (currentsong > 0) {
            setcurrentsong(currentsong - 1)
            ref.current.scrollToIndex({ animated: true, index: parseInt(currentsong) - 1 })
            await TrackPlayer.skipToPrevious()
            toggleplayback(playbackstate)
            
          }

        }}>
          <Icon name='play-skip-back-sharp' size={35} />
        </TouchableOpacity>
        <TouchableOpacity onPress={ async()=>{
          
          //await TrackPlayer.skip(currentsong)
          await toggleplayback(playbackstate)
        }}>
          <Icon name={btn?'pause-circle':'play-circle'} size={70} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={async() => {

            if (songs.length - 1 > currentsong) {
              setcurrentsong(currentsong + 1)
              ref.current.scrollToIndex({ animated: true, index: parseInt(currentsong) + 1 })
              const n=await TrackPlayer.skipToNext()
              toggleplayback(playbackstate)
              console.log(n+"next")
            }
          }}
        >

          <Icon name='play-skip-forward-sharp' size={35} />
        </TouchableOpacity>
      </View>
      <View style={{ flexDirection: 'row', marginTop: 50, width: '100%', justifyContent: 'space-evenly', alignItems: 'center' }}>
        <TouchableOpacity>

          <Icon name='shuffle' size={35} />
        </TouchableOpacity>
        <TouchableOpacity>

          <Icon name='repeat-sharp' size={35} />
        </TouchableOpacity>

      </View>



    </View>
  )
}

export default Music

const styles = StyleSheet.create({})